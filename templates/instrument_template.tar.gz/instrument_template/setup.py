#!/usr/bin/env python

# Copyright (c) 2009 - 2020, UChicago Argonne, LLC.
# See LICENSE file for details.


from setuptools import setup, find_packages
import os
import sys


setup (
    name='instrument',
    version='0.0.1',
    packages=['instrument',],
    )  
