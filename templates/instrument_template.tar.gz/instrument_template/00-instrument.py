
"""
start bluesky in IPython session for poof
"""

from instrument.collection import *

# show_ophyd_symbols()
# print_RE_md(printing=False)
