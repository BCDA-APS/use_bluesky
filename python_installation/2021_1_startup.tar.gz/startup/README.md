# README.md

[Instrument package](https://github.com/BCDA-APS/use_bluesky/tree/master/templates) for use with the Bluesky framework at beam line BEAMLINE_NAME, INSTRUMENT_NAME.

* Bluesky: https://blueskyproject.io/
* apstools: https://apstools.readthedocs.io/
* other instruments: https://github.com/BCDA-APS/use_bluesky/wiki/
